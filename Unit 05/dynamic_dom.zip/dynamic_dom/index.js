// Select DOM elements
const bookmarkLink = document.querySelector("#bookmark-link");
const bookmarkName = document.querySelector("#bookmark-name");
const addBtn = document.querySelector("#add");
const bookmarks = document.querySelector("#bookmarks");

// Use an array to keep track of bookmarks
let bookmarkData = [];

/**
 * @param {{link: string, name: string}} bookmark
 * @param {number} i  index of the bookmark in bookmarkData
 * @returns <li> element with corresponding link
 */
const createBookmarkElement = (bookmark, i) => {
  // Create <li>
  const li = document.createElement("li");
  li.className = "bookmark";

  // Create <a>
  const a = document.createElement("a");
  a.setAttribute("href", bookmark.link);
  a.textContent = bookmark.name;
  li.appendChild(a);

  // Create remove button
  const removeBtn = document.createElement("button");
  removeBtn.textContent = "-";
  removeBtn.addEventListener("click", () => {
    // Remove this link element and rerender
    bookmarkData = bookmarkData.filter((_, idx) => i != idx);
    renderBookmarks();
  });
  li.appendChild(removeBtn);

  return li;
};

/**
 * Create a bookmark element for each bookmark
 * in bookmarkData, and refresh the screen.
 */
const renderBookmarks = () => {
  const bookmarkElements = bookmarkData.map(createBookmarkElement);
  bookmarks.replaceChildren(...bookmarkElements);
};

/**
 * Add a new bookmark object to bookmarkData
 * when the addBtn is clicked, then rerender.
 */
addBtn.addEventListener("click", () => {
  const link = bookmarkLink.value;
  const name = bookmarkName.value;

  if (!link || !name) {
    console.log("no input");
    return;
  }

  bookmarkData.push({ link, name });
  renderBookmarks();
});
