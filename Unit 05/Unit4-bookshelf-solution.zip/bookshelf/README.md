# Foundations.Assessment.BookshelfData

## Overview

This time around, you've been assigned to build out an entire web app: Bookshelf helps users keep track of all the books they've read and all the books they might want to read.

This assessment will test your ability to design classes that show a solid understanding of OOP best practices and build a small project given high level descriptions.

Refer to Canvas for more information as well as the rubric.
